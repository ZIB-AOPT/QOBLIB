# converted from a010_t10_s01_b004_l1e-06.sol (bqp-lp)
instance po_a010_t10_s01
budget 4
lambda 1e-06
objective -145362
# period symbol long short
0 AVGO 1 0
0 NVDA 3 0
1 AVGO 1 0
1 NVDA 3 0
2 AVGO 1 0
2 NVDA 3 0
3 AMZN 3 0
3 META 1 0
4 META 1 0
4 NVDA 3 0
5 META 1 0
5 NVDA 3 0
6 GOOG 1 0
6 GOOGL 3 0
7 GOOG 0 1
7 GOOGL 0 3
8 AAPL 0 1
8 NVDA 3 0
