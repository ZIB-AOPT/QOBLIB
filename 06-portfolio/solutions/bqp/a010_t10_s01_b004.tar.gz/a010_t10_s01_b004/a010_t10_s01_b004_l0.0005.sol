# converted from a010_t10_s01_b004_l0.0005.sol (bqp-lp)
instance po_a010_t10_s01
budget 4
lambda 0.0005
objective -39933
# period symbol long short
0 AAPL 0 2
0 AVGO 1 0
0 NVDA 1 0
1 AAPL 0 1
1 AVGO 1 0
1 WMT 0 2
2 AAPL 0 1
2 WMT 0 3
3 AAPL 0 1
3 AMZN 1 0
3 WMT 0 2
4 AVGO 1 0
4 META 1 0
4 TSLA 0 1
4 WMT 1 0
5 AAPL 0 2
5 MSFT 2 0
6 MSFT 1 0
7 AAPL 0 2
7 WMT 1 0
8 AAPL 0 2
8 GOOG 1 0
8 WMT 1 0
