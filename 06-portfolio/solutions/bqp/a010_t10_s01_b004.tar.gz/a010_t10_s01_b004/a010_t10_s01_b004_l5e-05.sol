# converted from a010_t10_s01_b004_l5e-05.sol (bqp-lp)
instance po_a010_t10_s01
budget 4
lambda 5e-05
objective -103323
# period symbol long short
0 AVGO 1 0
0 NVDA 3 0
1 AAPL 0 2
1 NVDA 2 0
2 AAPL 0 1
2 NVDA 1 0
2 WMT 0 2
3 AAPL 0 1
3 AMZN 3 0
4 META 1 0
4 NVDA 2 0
4 TSLA 0 1
5 AAPL 0 1
5 META 1 0
5 NVDA 2 0
6 GOOG 3 0
6 META 1 0
7 AAPL 0 3
7 AMZN 0 1
8 AAPL 0 3
8 NVDA 1 0
