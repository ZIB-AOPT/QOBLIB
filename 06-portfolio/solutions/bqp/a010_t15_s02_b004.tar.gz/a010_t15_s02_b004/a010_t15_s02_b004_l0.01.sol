# converted from a010_t15_s02_b004_l0.01.sol (bqp-lp)
instance po_a010_t15_s02
budget 4
lambda 0.01
objective -1500
# period symbol long short
