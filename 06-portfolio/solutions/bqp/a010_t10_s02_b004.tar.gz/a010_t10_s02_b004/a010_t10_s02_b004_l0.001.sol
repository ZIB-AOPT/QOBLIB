# converted from a010_t10_s02_b004_l0.001.sol (bqp-lp)
instance po_a010_t10_s02
budget 4
lambda 0.001
objective -6053
# period symbol long short
1 GOOG 0 1
1 MSFT 1 0
1 WMT 0 1
2 AAPL 1 0
2 AMZN 1 0
2 MSFT 0 2
3 AAPL 1 0
5 AAPL 1 0
5 MSFT 1 0
5 TSLA 0 1
7 AAPL 0 2
7 GOOG 1 0
7 TSLA 1 0
