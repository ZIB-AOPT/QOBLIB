# converted from a010_t10_s02_b004_l1e-06.sol (bqp-lp)
instance po_a010_t10_s02
budget 4
lambda 1e-06
objective -120706
# period symbol long short
0 AVGO 1 0
0 NVDA 3 0
1 META 1 0
1 NVDA 3 0
2 NVDA 0 1
2 TSLA 3 0
3 AVGO 1 0
3 NVDA 3 0
4 GOOG 3 0
4 GOOGL 1 0
5 NVDA 3 0
5 TSLA 0 1
6 AAPL 0 1
6 AVGO 3 0
7 AAPL 0 1
7 META 0 3
8 AVGO 0 3
8 META 0 1
