# converted from a010_t10_s00_b004_l5e-05.sol (bqp-lp)
instance po_a010_t10_s00
budget 4
lambda 5e-05
objective -169115
# period symbol long short
0 AVGO 1 0
0 NVDA 3 0
1 AVGO 2 0
1 TSLA 2 0
2 AAPL 0 2
2 TSLA 0 2
3 AVGO 2 0
3 GOOGL 2 0
4 NVDA 1 0
4 TSLA 0 3
5 AAPL 0 1
5 TSLA 3 0
6 AAPL 1 0
6 AVGO 0 1
6 TSLA 2 0
7 AMZN 1 0
7 GOOG 0 2
7 TSLA 0 1
8 MSFT 0 3
8 NVDA 1 0
