# converted from a010_t10_s00_b004_l1e-05.sol (bqp-lp)
instance po_a010_t10_s00
budget 4
lambda 1e-05
objective -204770
# period symbol long short
0 AVGO 1 0
0 NVDA 3 0
1 AVGO 3 0
1 TSLA 1 0
2 AAPL 0 1
2 TSLA 0 3
3 AVGO 3 0
3 NVDA 1 0
4 NVDA 2 0
4 TSLA 0 2
5 META 0 1
5 TSLA 3 0
6 AVGO 0 2
6 TSLA 2 0
7 GOOGL 0 2
7 TSLA 0 2
8 GOOGL 0 2
8 NVDA 2 0
